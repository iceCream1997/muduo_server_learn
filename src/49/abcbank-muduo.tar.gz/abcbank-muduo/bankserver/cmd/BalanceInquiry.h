#ifndef _BALANCE_INQUIRY_H_
#define _BALANCE_INQUIRY_H_

#include "Transaction.h"

// ��ѯ���

class BalanceInquiry : public Transaction
{
public:
	virtual void Execute(BankSession& session);
};



#endif // _BALANCE_INQUIRY_H_
